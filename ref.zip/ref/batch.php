<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <?php include('include/allcsslink.php'); ?>
  </head>
  <body>
   <?php include('include/sidebar.php'); ?>
    <div class="page">
      <!-- navbar-->
      <?php
        include('include/headerfornav.php');
      ?>
       <!-- Breadcrumb-->
       <div class="breadcrumb-holder" background="#234">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Batch       </li>
          </ul>
        </div>
        </div>
     <!--content section -->
     <main class="page-content">
      <div class="container mt-5">
          <div class="card card-body">
            <div class="d-flex">
              <h2 class="text-success ">Department of  Master of Computer Applications</h3>
              <h3 class="text-success ml-auto"><a href="#" data-toggle="modal" data-target="#addbatch"><i class="fa fa-plus" aria-hidden="true"></i></a></h3>
            </div>
            <hr>
            <div class="row">
            </div>
          </div>
      </div>
    </main>
      </main>
     <!--end of content section-->
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>...</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Copyright © 2020 - Cambridge Group of Institutions All rights reserved</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>