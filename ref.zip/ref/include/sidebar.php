 <!-- Side Navbar -->
 <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <!-- User Info-->
          <div class="sidenav-header-inner text-center"><img src="img/avatar-0.jpg" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5">ARUNA DEVI</h2><span>HOD MCA</span>
          </div>
          <!-- Small Brand information, appears on minimized sidebar-->
          <div class="sidenav-header-logo"><a href="index.php" class="brand-small text-center"> <strong>MCA</strong></a></div>
        </div>
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="index.php"> <i class="icon-home"></i>Home                             </a></li>
            <li><a href="#Profile" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-user"></i>Profile </a>
              <ul id="Profile" class="collapse list-unstyled ">
                <li><a href="#">Personal Info</a></li>
                <li><a href="#">Official Info</a></li>
              </ul>
            </li>
            <li><a href="batch.php"> <i class="fa fa-object-group"></i>Batchs                             </a></li>
            <li><a href="people.php"> <i class="fa fa-users"></i></i>People                             </a></li>
            <li><a href="#Schedule" aria-expanded="false" data-toggle="collapse"> <i class="icon-clock"></i>Schedule </a>
              <ul id="Schedule" class="collapse list-unstyled ">
                <li><a href="#">Time Slot</a></li>
                <li><a href="#">Meeting Scheduler</a></li>
              </ul>
            </li>
            <li><a href="#Leave" aria-expanded="false" data-toggle="collapse"> <i class="icon-clock"></i>Leave </a>
              <ul id="Leave" class="collapse list-unstyled ">
                <li><a href="#">Manage Leave</a></li>
                <li><a href="#">Leave Management System</a></li>
              </ul>
            </li>
            <li><a href="#Procurement" aria-expanded="false" data-toggle="collapse"> <i class="icon-inr"></i>Procurement </a>
              <ul id="Procurement" class="collapse list-unstyled ">
                <li><a href="#">Indent Form</a></li>
                <li><a href="#">reviews</a></li>
              </ul>
            </li>
            <li><a href="charts.php"> <i class="fa fa-bar-chart"></i>Analytics                            </a></li>
            <li><a href="login.html"> <i class="fa fa-sign-out"></i>Log out                             </a></li>
          </ul>
        </div>
      </div>
    </nav>
    