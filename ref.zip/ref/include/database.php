<?php

$con = mysqli_connect("localhost","root","","citechlms");

if($con){
    echo "";
  }
  else{
    die("Connection Fail because ".mysqli_connect_error());
  }

?>