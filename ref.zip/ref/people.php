<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">

    <?php include('include/allcsslink.php'); ?>
  </head>
  <body>
    <!-- Side Navbar -->
    <?php include('include/sidebar.php'); ?>
    <div class="page">
      <!-- navbar-->
      <?php
        include('include/headerfornav.php');
      ?>
      

      <section>
        <div class="container-fluid">
          <!-- Page Header-->
          <header> 
            <h1 class="h3 display">people  </h1>
          </header>
          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex">
                  <h4>Admins</h4>
                  <h3 class="text-success ml-auto"><a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a></h3>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Mail ID</th>
                        </tr>
                      </thead>
                      <tbody>
              
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex">
                  <h4>Teachers</h4>
                  <h3 class="text-success ml-auto"><a href="#" data-toggle="modal" data-target="#addteacher"><i class="fa fa-plus" aria-hidden="true"></i></a></h3>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>teacher Id</th>
                          <th>Teacher Name</th>
                          <th>Teacher Email Id</th>
                        </tr>
                      </thead>
                      <tbody>
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex">
                  <h4>Students</h4>
                  </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>USN</th>
                          <th>Name</th>
                          <th>Mail ID</th>
                          <th>Batch</th>
                        </tr>
                      </thead>
                      <tbody>    
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>   
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>...</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Copyright © 2020 - Cambridge Group of Institutions All rights reserved</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>